# AESNO Corporation – Static Site

This package contains a single-file static site (`index.html`). All images are embedded, so you can host it anywhere with zero extra assets.

## Quick Preview (Local)
- Double-click `index.html` to open in your browser; or
- In a terminal:
  ```bash
  python3 -m http.server 8080
  # open http://localhost:8080
  ```

## Deploy to GitHub Pages
1. Create a new repository on GitHub (public or private).
2. Upload `index.html` (or drag/drop the whole ZIP contents).
3. Commit to the `main` branch.
4. Go to **Settings → Pages**.
5. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
6. Select **Branch: main** and **/ (root)**. Save.
7. Your site will be live shortly at: `https://<your-username>.github.io/<your-repo>/`

## Deploy to Netlify (drag-and-drop)
1. Log into Netlify.
2. Go to **Sites** → **Add new site** → **Deploy manually**.
3. Drag-and-drop `index.html` (or the whole folder).

## Deploy to Vercel
1. Log into Vercel.
2. Create a new project from your GitHub repo containing `index.html`.
3. Accept defaults and deploy.

## Notes
- Update contact details directly inside `index.html` (search for email, phone, address).
- Colors used: Navy `#0C2D57`, Red `#E31C23`, Light Blue `#9BB8D3`, Gray `#F2F2F2`, Dark `#333333`, White `#FFFFFF`.
- Copyright © 2025 AESNO Corporation.
